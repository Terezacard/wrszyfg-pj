function calcularMedia() {
    let totalNotas = 0;
    let contadorNotas = 0;

    // Loop para pegar as 15 notas e somar
    for (let i = 1; i <= 15; i++) {
        let nota = parseFloat(document.getElementById('nota' + i).value);
        if (!isNaN(nota) && nota !== "") {
            totalNotas += nota;
            contadorNotas++;
        }
    }

    // Se pelo menos uma nota foi preenchida
    if (contadorNotas > 1) {
        let media = totalNotas / contadorNotas;
        document.getElementById('resultado').innerHTML = 'A média das suas notas é: ' + media.toFixed(2);
        document.getElementById('resultado').style.display = 'block';
    } else {
        alert('Por favor, insira pelo menos uma nota!');
    }
}
